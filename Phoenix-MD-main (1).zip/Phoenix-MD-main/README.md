   # Phoenix-MD 
<div align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Ribeye&size=50&pause=1000&color=F710B1&center=true&width=910&height=100&lines=I'M+Phoenix-MD;Multi+Divice+Whatsapp+Bot;Coded+By+Abhishek Suresh" alt="Typing SVG" /></a>
  
<p align="center">  
  <a href="https://youtube.com/channel/UCLUS9v7q4JagAqIJ3eeMM8w">
    <img alt=Phoenix-MD height="300" src="https://i.ibb.co/tHWJrz3/IMG-20231128-WA0005.jpg">
   
</a> 
    
</p>
<p align="center">
<a 

####  
Phoenix-MD Multi Device Whatsapp Bot.
## <sub>[External Plugins](https://github.com/AbhishekSuresh2/External-Plugins)</sub>

***

#### SETUP

Fork The Repo
    <br>
<a href="https://github.com/AbhishekSuresh2/Phoenix-MD/fork"><img title="Phoenix-MD" src="https://img.shields.io/badge/FORK Phoenix MD-h?color=black&style=for-the-badge&logo=stackshare"></a>

#### Session ID

<a href="https://phoenix-md-qr.onrender.com/"><img title="Phoenix-MD Session ID" src="https://img.shields.io/badge/GET SESSION ID-h?color=black&style=for-the-badge&logo=msi"></a>

## Phoenix-MD Deploy Method

### Deploy Actions/WorkFlows(Free 24/7 Trick)

<a href="https://youtu.be/ZSwJtaN0BUk?si=FOsYpMs4WbvBFCpY"><img title="Phoenix-MD Deploy Actions/WorkFlows" src="https://img.shields.io/badge/Free Deploy Tutorial-h?color=black&style=for-the-badge&logo=visualstudiocode"></a>


### Deploy Codespace(Free)

<a href="https://github.com/codespaces/new"><img title="Phoenix-MD Deploy CodeSpace" src="https://img.shields.io/badge/DEPLOY CODESPACE-h?color=black&style=for-the-badge&logo=visualstudiocode"></a>

### Codespace Tutorial

<a href="https://youtu.be/ZSwJtaN0BUk?si=FOsYpMs4WbvBFCpY"><img title="Phoenix-MD Deploy CodeSpace" src="https://img.shields.io/badge/Codespace Tutorial-h?color=black&style=for-the-badge&logo=visualstudiocode"></a>

### Deploy Heroku 

<a href="https://heroku.com/deploy?template=https://github.com/AbhishekSuresh2/Phoenix-MD/"><img title="Phoenix-MD Deploy Heroku" src="https://img.shields.io/badge/DEPLOY HEROKU-h?color=black&style=for-the-badge&logo=heroku"></a>

### Heroku Tutorial

<a href="https://youtu.be/sDojtm-bwN4?si=gbvAqTOSfuVRU2-k"><img title="Heroku Tutorial" src="https://img.shields.io/badge/Heroku Tutorial-h?color=black&style=for-the-badge&logo=heroku"></a>
### Deploy Railway

<a href="https://railway.app/new"><img title="Phoenix-MD Deploy Railway" src="https://img.shields.io/badge/DEPLOY RAILWAY-h?color=black&style=for-the-badge&logo=Railway"></a> 
 
 ## Support

SUPPORT GROUP: <a href="https://chat.whatsapp.com/BOLb0ICN3sAJ5dloRBw5VD"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

**Star ⭐ The Repo For Amazing Commands**

